#include "global.h"

extern struct pipelineReg PR[];
extern struct pipelineReg SHADOW_PR[];
extern int forwardMEM_WBOp1, forwardMEM_WBOp2, forwardEX_MEMOp1, forwardEX_MEMOp2;
extern int stallIF;


void handleForwarding() {

  /* Set the four signals to control the inputs to the multiplexers to the ALU in the EX stage. 
      
      forwardEX_MEMOp1: set to TRUE if and only if "src1" of the instruction in the EX stage has a RAW dependency 
      on the instruction in the  EX_MEM pipeline register.
      forwardMEM_WBOp1: set to TRUE if and only if "src1" of the instruction in the EX stage has a RAW dependency 
      on the instruction in the MEM_WB pipeline register.
    
      forwardEX_MEMOp2:  Same as "forwardEX_MEMOp1" for "src2" of instruction in the EX stage.
      forwardMEM_WBOp2:  Same as "forwardMEM_WBOp1" for "src2" of instruction in the EX stage.
  */


}



void checkDataHazard() {

  /* Set the signal "stallIF" to stall the instruction in the ISSUE stage for an additional cycle.
   stallIF: Set to TRUE if and only if the instruction in the ISSUE stage has a RAW dependency with 
   a LOAD instruction immediately ahead of it in the pipeline.
  */

  
}

